﻿using ConvertApiDotNet;
using ConvertApiDotNet.Exceptions;
using ConvertApiDotNet.Model;
using System.Net;

namespace Docx_to_PDF
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            // Creating ConvertApi instance and providing our secret key
           // var convertapi = new ConvertApi("XAo7msjHo6AS1iqj");
            //request.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
            //WebRequest.DefaultWebProxy.Credentials = CredentialCache.DefaultNetworkCredentials;

            foreach (var docxFile in Directory.EnumerateFiles(@"C:\Users\IN0137\Downloads"))
            {
                try
                {
                    var convertApi = new ConvertApi("XAo7msjHo6AS1iqj");
                    var conversionTask = await convertApi.ConvertAsync("docx", "pdf",
                        new ConvertApiFileParam(@"c:\Users\IN0137\Downloads")
                        );
                    var fileSaved = await conversionTask.Files.SaveFilesAsync(@"c:\");
                }
                //Catch exceptions from asynchronous methods
                catch (ConvertApiException e)
                {
                    Console.WriteLine("Status Code: " + e.StatusCode);
                    Console.WriteLine("Response: " + e.Response);

                    if (e.StatusCode == HttpStatusCode.Unauthorized)
                        Console.WriteLine("Secret is not provided or no additional seconds left in account to proceed conversion. More information https://www.convertapi.com/a");
                }
            }
        }
    }
}