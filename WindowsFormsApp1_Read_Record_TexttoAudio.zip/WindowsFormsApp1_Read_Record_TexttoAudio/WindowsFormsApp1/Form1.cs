﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.IO;
using System.IO.Pipes;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SpeechSynthesizer synth;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            synth = new SpeechSynthesizer();
            synth.Rate = trkspeed.Value;
            synth.Volume = trkvolume.Value;
            synth.SpeakAsync(txtbox.Text);
        }

        private void btnpause_Click(object sender, EventArgs e)
        {
            synth.Pause();
        }

        private void btnresume_Click(object sender, EventArgs e)
        {
            synth.Resume();
        }

        private void btnopen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "text files|*.txt";
            ofd.ShowDialog();
            string fname=ofd.FileName;
            StreamReader sr = new StreamReader(fname);
            txtbox.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void btnrecord_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Wave Files|*.wav";
            sfd.ShowDialog();
            string fname=sfd.FileName;
            SpeechSynthesizer ss=new SpeechSynthesizer();
            ss.Rate = trkspeed.Value;
            ss.Volume = trkvolume.Value;
            ss.SetOutputToWaveFile(fname);
            ss.Speak(txtbox.Text);
            ss.SetOutputToDefaultAudioDevice();
            MessageBox.Show("Text Recorded as Wave file");
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
