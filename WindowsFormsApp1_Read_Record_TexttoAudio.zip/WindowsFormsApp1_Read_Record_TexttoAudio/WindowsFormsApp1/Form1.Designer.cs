﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRead = new System.Windows.Forms.Button();
            this.txtbox = new System.Windows.Forms.TextBox();
            this.trkspeed = new System.Windows.Forms.TrackBar();
            this.trkvolume = new System.Windows.Forms.TrackBar();
            this.btnpause = new System.Windows.Forms.Button();
            this.btnresume = new System.Windows.Forms.Button();
            this.btnopen = new System.Windows.Forms.Button();
            this.btnrecord = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblspeed = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.trkspeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkvolume)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(233, 260);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(141, 32);
            this.btnRead.TabIndex = 0;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // txtbox
            // 
            this.txtbox.Location = new System.Drawing.Point(32, 23);
            this.txtbox.Multiline = true;
            this.txtbox.Name = "txtbox";
            this.txtbox.Size = new System.Drawing.Size(489, 189);
            this.txtbox.TabIndex = 1;
            // 
            // trkspeed
            // 
            this.trkspeed.Location = new System.Drawing.Point(32, 260);
            this.trkspeed.Name = "trkspeed";
            this.trkspeed.Size = new System.Drawing.Size(143, 45);
            this.trkspeed.TabIndex = 2;
            // 
            // trkvolume
            // 
            this.trkvolume.Location = new System.Drawing.Point(32, 349);
            this.trkvolume.Name = "trkvolume";
            this.trkvolume.Size = new System.Drawing.Size(143, 45);
            this.trkvolume.TabIndex = 4;
            // 
            // btnpause
            // 
            this.btnpause.Location = new System.Drawing.Point(380, 260);
            this.btnpause.Name = "btnpause";
            this.btnpause.Size = new System.Drawing.Size(141, 32);
            this.btnpause.TabIndex = 5;
            this.btnpause.Text = "Pause";
            this.btnpause.UseVisualStyleBackColor = true;
            this.btnpause.Click += new System.EventHandler(this.btnpause_Click);
            // 
            // btnresume
            // 
            this.btnresume.Location = new System.Drawing.Point(233, 312);
            this.btnresume.Name = "btnresume";
            this.btnresume.Size = new System.Drawing.Size(141, 32);
            this.btnresume.TabIndex = 7;
            this.btnresume.Text = "Resume";
            this.btnresume.UseVisualStyleBackColor = true;
            this.btnresume.Click += new System.EventHandler(this.btnresume_Click);
            // 
            // btnopen
            // 
            this.btnopen.Location = new System.Drawing.Point(380, 312);
            this.btnopen.Name = "btnopen";
            this.btnopen.Size = new System.Drawing.Size(141, 32);
            this.btnopen.TabIndex = 9;
            this.btnopen.Text = "Open";
            this.btnopen.UseVisualStyleBackColor = true;
            this.btnopen.Click += new System.EventHandler(this.btnopen_Click);
            // 
            // btnrecord
            // 
            this.btnrecord.Location = new System.Drawing.Point(233, 362);
            this.btnrecord.Name = "btnrecord";
            this.btnrecord.Size = new System.Drawing.Size(141, 32);
            this.btnrecord.TabIndex = 11;
            this.btnrecord.Text = "Record";
            this.btnrecord.UseVisualStyleBackColor = true;
            this.btnrecord.Click += new System.EventHandler(this.btnrecord_Click);
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(380, 362);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(141, 32);
            this.btnexit.TabIndex = 13;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblspeed
            // 
            this.lblspeed.AutoSize = true;
            this.lblspeed.Location = new System.Drawing.Point(40, 244);
            this.lblspeed.Name = "lblspeed";
            this.lblspeed.Size = new System.Drawing.Size(38, 13);
            this.lblspeed.TabIndex = 14;
            this.lblspeed.Text = "Speed";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Location = new System.Drawing.Point(40, 322);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(42, 13);
            this.lblVolume.TabIndex = 15;
            this.lblVolume.Text = "Volume";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(547, 436);
            this.Controls.Add(this.lblVolume);
            this.Controls.Add(this.lblspeed);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnrecord);
            this.Controls.Add(this.btnopen);
            this.Controls.Add(this.btnresume);
            this.Controls.Add(this.btnpause);
            this.Controls.Add(this.trkvolume);
            this.Controls.Add(this.trkspeed);
            this.Controls.Add(this.txtbox);
            this.Controls.Add(this.btnRead);
            this.Name = "Form1";
            this.Text = "Text-to-Audio";
            ((System.ComponentModel.ISupportInitialize)(this.trkspeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkvolume)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.TextBox txtbox;
        private System.Windows.Forms.TrackBar trkspeed;
        private System.Windows.Forms.TrackBar trkvolume;
        private System.Windows.Forms.Button btnpause;
        private System.Windows.Forms.Button btnresume;
        private System.Windows.Forms.Button btnopen;
        private System.Windows.Forms.Button btnrecord;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblspeed;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

