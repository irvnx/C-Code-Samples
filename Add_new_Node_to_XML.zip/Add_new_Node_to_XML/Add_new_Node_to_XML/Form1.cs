﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Add_new_Node_to_XML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClickThis_Click(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("C:\\Users\\IN0137\\BookList.xml");

            XmlNode BookID = doc.CreateElement("BookID");
            XmlNode Author = doc.CreateElement("Author");
            Author.InnerText = txtbox2.Text;
            BookID.AppendChild(Author);
            

            XmlNode Title = doc.CreateElement("Title");
            Title.InnerText = txtbox3.Text;
            BookID.AppendChild(Title);

            XmlNode Genre = doc.CreateElement("Genre");
            Genre.InnerText = txtbox4.Text;
            BookID.AppendChild(Genre);

            XmlNode Price = doc.CreateElement("Price");
            Price.InnerText = txtbox5.Text;
            BookID.AppendChild(Price);

           // XmlNode Publish_Date = doc.CreateElement("Publish Date");
            //Publish_Date.InnerText = txtbox6.Text;
            //BookID.AppendChild(Publish_Date);
            doc.DocumentElement.AppendChild(BookID);
            doc.Save("C:\\Users\\IN0137\\BookList.xml");
        }
    }
}
