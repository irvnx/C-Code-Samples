﻿using NTextCat;
using DetectLanguage;

namespace detectlang
{
    class program
    {
        private static string _url = "https://detectlanguage.com/private";
        static async Task Main(string[] args)
        {
            try
            {
                using (var _client = new HttpClient())
                {
                    var response = await _client.GetAsync(_url);

                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                    DetectLanguageClient client = new DetectLanguageClient("372308ede24e30f6f9087f35900a3d44");
                    DetectResult[] results = await client.DetectAsync("Buenos dias señor");
                    string[] texts = { "labas rytas", "good morning" };
                    DetectResult[][] results1 = await client.BatchDetectAsync(texts);
                    UserStatus userStatus = await client.GetUserStatusAsync();
                    Language[] languages = await client.GetLanguagesAsync();
                    Console.WriteLine(results);
                }
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}

