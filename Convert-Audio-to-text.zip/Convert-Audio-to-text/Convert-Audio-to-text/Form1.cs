﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Convert_Audio_to_text
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtbox1.Text != "")
            {
                SpeechSynthesizer ss = new SpeechSynthesizer();
                ss.Volume= trackBar1.Value;
                ss.Speak(txtbox1.Text);
            }
            else
            {
                MessageBox.Show("Please write something First");

            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            SpeechRecognitionEngine sr=new SpeechRecognitionEngine();
            Grammar word = new DictationGrammar();
            sr.LoadGrammar(word);
            sr.BabbleTimeout = new TimeSpan(Int32.MaxValue);
            sr.InitialSilenceTimeout = new TimeSpan(Int32.MaxValue);
            sr.EndSilenceTimeout = new TimeSpan(100000000);
            sr.EndSilenceTimeoutAmbiguous = new TimeSpan(100000000);
            try
            {
                txtbox2.Text = "Listening Now...";
                //sr.SetInputToDefaultAudioDevice();
                sr.SetInputToWaveFile("C:\\Users\\IN0137\\Downloads\\W_Audio.wav");
                RecognitionResult result = sr.Recognize();
                txtbox2.Clear();
                txtbox2.Text = result.Text;
                TextWriter text1 = new StreamWriter("C:\\foxtrit.txt");
                text1.Write(txtbox2.Text);
                text1.Close();
            }
            catch
            {
                txtbox2.Text = "";
                MessageBox.Show("Mic Not Found");
            }
            finally
            {
                sr.UnloadAllGrammars();
            }
        }
    }
}
